# lavish-local

An offline, telemetry-free replica of [`lavish-axi`](https://github.com/kunchenguid/lavish-axi)
(0.1.90): the review surface firstmate's `/bearings lavish` fleet board, and any
other agent-authored HTML artifact, is opened and answered through.

It exists because stock `lavish-axi` reports every CLI invocation to Umami
analytics at `a.kunchenguid.com` (website id hardcoded in `dist/cli.mjs`,
opt-out only via `LAVISH_AXI_TELEMETRY=off`), can publish artifacts to the
third-party host `ht-ml.app` (`share`), and resolves its own Tailscale MagicDNS
name on every open. This replica makes **zero outbound connections**: no
telemetry, no update check, no CDN fetch, no publishing. It uses only `node:`
built-ins (Node 22+) and has no npm dependencies.

## Drop-in contract

The binary is named `lavish-axi` so firstmate's scripts run unchanged:

| firstmate relies on | replica behaviour |
| --- | --- |
| `lavish-axi --version` ≥ 0.1.80 (`bin/fm-bootstrap.sh`) | prints `0.1.90-local` |
| `lavish-axi <file>` exits 0 and prints `status: opened` / `user-ended` | same TOON block; `--reopen` reopens a user-ended session |
| `lavish-axi` listing rows `<file>,open,"<url>",<pending>,<listener>` | same table, same header |
| session key = `sha256(realpath)[:16]`, stored in `~/.lavish-axi/state.json` as `sessions[key].{file,url}` | identical derivation and store layout (`LAVISH_AXI_STATE_DIR` honoured) |
| `lavish-axi poll <file>` long-polls; feedback as `prompts[N]{uid,prompt,selector,tag,text}:` (table) or list form with nested `target`; `session_ended: true` + `ended_by` on Send & End; `status: ended|waiting|browser_disconnected` | identical shapes, verified against `bin/fm-procevent-lavish.sh answers/read/classify/terminal` |
| `lavish-axi reply <file> --agent-reply ...` exits 0 after acceptance | same |
| `lavish-axi end <file>`, `lavish-axi stop` | same |
| errors as `error: ...` + `code: NOT_FOUND|SERVER_ERROR|LISTENER_ACTIVE|...` | same |
| in-artifact `window.lavish.queuePrompt(prompt, {tag,text,element,data,queueKey})`, `data-lavish-question` | same API; `data` is appended as `Context data:` JSON exactly like stock |

Not replicated on purpose: `share` (refused), `setup hooks|plugin` (refused),
layout-issue diagnostics, Mermaid whiteboards, image attachments, revisions
legend. `export` inlines local assets only.

## Maintenance

`~/firstmate-vendor/TRACKS.md` is the map of the stock-versus-secure setup on
this box and owns the update procedures (upstream firstmate merge, a new
lavish-axi release, changes to this replica, re-packing into the vendor
directory). The packed copy is `~/firstmate-vendor/npm/lavish-local-1.0.0.tgz`;
re-pack with `npm pack --pack-destination ~/firstmate-vendor/npm` and
regenerate `npm/SHA256SUMS` after any change here. Source of record is the
private repository `git@github.com:MaraCoding/lavish-local.git` (branch
`main`); it is an independent rewrite, not a fork of upstream, and nothing
here is ever pushed to the upstream author's repository.

## Install (secure track)

```sh
ln -sf ~/lavish-local/bin/lavish-axi ~/.local/bin/lavish-axi   # ~/.local/bin precedes ~/.npm-global/bin
lavish-axi --version                                           # 0.1.90-local
```

Both firstmate tracks live on one box, so the secure track uses port 4388
(`LAVISH_AXI_PORT=4388` in `~/.local/bin/fm-pi`) while the stock control keeps
4387. The replica refuses to start on a port that another Lavish server holds.

## Network surface

The server binds loopback and, when `tailscale ip -4` answers (a local
command), the Tailscale IPv4 so the board can be opened from another device on
the tailnet. Printed URLs use that IP (no MagicDNS lookup). Reviewer routes
(`/api/<key>/prompts`, `/end`) accept only same-origin browser requests;
agent routes (`/api/open`, `/poll`, `/reply`, `/list`, `/shutdown`) accept
only loopback peers without an `Origin` header.

| variable | meaning |
| --- | --- |
| `LAVISH_AXI_PORT` | port (default 4387) |
| `LAVISH_AXI_HOST` | explicit bind host; disables Tailscale auto-bind |
| `LAVISH_AXI_LINK_HOST` | host written into session URLs |
| `LAVISH_AXI_ALLOWED_HOSTS` | extra hostnames accepted on reviewer routes (`*` = any) |
| `LAVISH_AXI_NO_TAILSCALE=1` | loopback only |
| `LAVISH_AXI_NO_OPEN=1` | never launch a browser (headless hosts skip it anyway) |
| `LAVISH_AXI_STATE_DIR` | state directory (default `~/.lavish-axi`) |
| `LAVISH_AXI_DISCONNECT_GRACE_MS` | reconnect grace before `browser_disconnected` (10 s, as upstream) |
| `LAVISH_AXI_IDLE_TIMEOUT_MS` | self-stop after this long with no review page or poll connected (30 min, as upstream; `0`/`off` disables) |

## Behaviours ported from the upstream source

Checked against `kunchenguid/lavish-axi` at 0.1.93 (`docs/invariants.md`, `AGENTS.md`):

- Output goes through a port of `@toon-format/toon` 2.3.1's rules; `test/toon-parity.mjs` proves byte parity with captured stock output.
- Poll feedback field order is `prompts`, `next_step`, `dom_snapshot`.
- `takeFeedback` is destructive, so a poll whose client disappears before the response is written gets its batch restored to the front of the queue and its Seen stamps undone.
- Poll ownership is exclusive per session (`LISTENER_ACTIVE`; `--takeover` hands the old poll `LISTENER_REPLACED`).
- Every review window gone for the grace period returns `browser_disconnected` to the open poll; the session stays resumable.
- The last open session ending with nothing connected stops the server, as does 30 min with no live connection; any later command restarts it from `state.json`.
- The review page sends `X-Frame-Options: DENY` and `frame-ancestors 'none'`; every `/artifact/*` response carries the iframe's `sandbox` CSP.
- The chrome mints each queued prompt's `prompt_id`; a queued note leaves the queue only when the transcript acknowledges that id; a resend with a known id is ignored; the id never reaches the agent.
- Queue keys follow upstream: explicit `queueKey`, else `question:<key>` inside `data-lavish-question`, else radio/checkbox/field keys, so a re-answer replaces the unsent earlier one.
- Answers inside `data-lavish-question` scopes are reported as review state and replayed after a live reload without synthetic events.
- Annotate mode ignores native controls, ARIA widgets, editable regions and `data-lavish-action`; Ctrl/Cmd+I toggles it from either side; modifier-click follows links.
- `/api/:key/prompts` rejects batches for an ended session (409); a user-ended session never reopens without `--reopen`.

Evidence from `bin/fm-egress-audit.sh` (strace of a full open → list → poll →
reply → export → end → stop cycle, server included): `connects: 0`,
`verdict: clean`. The same audit of the stock build shows
`a.kunchenguid.com 443 unexpected`.

## Test

```sh
bash test/e2e.sh          # CLI cycle + firstmate adapter parse + headless Chromium click-through
bash test/lifecycle.sh    # headers, prompt_id dedupe, poll ownership, disconnect grace, self-stop + restart
node test/toon-parity.mjs # byte parity with captured stock output
```

`test/browser-drive.mjs` drives `/usr/bin/chromium` over the DevTools
protocol with nothing but `node:` built-ins; it also works against the stock
page.
