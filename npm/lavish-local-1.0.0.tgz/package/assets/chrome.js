/* lavish-local review page. Talks only to its own origin. */
(function () {
  "use strict";
  var cfg = JSON.parse(document.getElementById("lavish-config").textContent);
  var key = cfg.key;
  var $ = function (id) { return document.getElementById(id); };
  var frame = $("artifact");
  var chatLog = $("chatLog");
  var queuedLog = $("queuedLog");
  var chatInput = $("chatInput");
  var sendBtn = $("send");
  var sendEndBtn = $("sendAndEnd");
  var presence = $("presenceBanner");
  var endedBanner = $("endedBanner");
  var summary = $("panelSummary");
  var agentPill = $("agentPill");
  var agentState = $("agentState");
  var annotation = $("annotation");
  var annotCard = $("annotCard");

  var queue = [];           // unsent prompts
  var annotate = true;
  var ended = false;
  var lastScroll = null;
  var artifactRevision = 0;
  var sentAt = 0;           // when we last sent; agent reply after it clears Working
  var lastChat = { chat: [], listener: false };
  var storageKey = "lavish-local:queue:" + key;
  try { var saved = JSON.parse(sessionStorage.getItem(storageKey) || "[]"); if (Array.isArray(saved)) queue = saved; } catch (e) { /* ignore */ }

  function artifactSrc() { return "/artifact/" + key + "/index.html?r=" + artifactRevision; }
  function loadArtifact() { frame.src = artifactSrc(); }
  loadArtifact();

  function postToFrame(msg) { try { frame.contentWindow.postMessage(msg, "*"); } catch (e) { /* ignore */ } }

  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }

  /* tiny safe markdown subset: paragraphs, - / 1. lists, ## headings, **bold**, `code`, fenced code */
  function inline(s) {
    return esc(s).replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  }
  function markdown(text) {
    var lines = String(text || "").replace(/\r\n?/g, "\n").split("\n");
    var html = [], para = [], list = null, fence = null;
    function flushPara() { if (para.length) { html.push("<p>" + para.map(inline).join("<br>") + "</p>"); para = []; } }
    function flushList() { if (list) { html.push("<" + list.tag + ">" + list.items.map(function (i) { return "<li>" + inline(i) + "</li>"; }).join("") + "</" + list.tag + ">"); list = null; } }
    for (var i = 0; i < lines.length; i++) {
      var l = lines[i];
      if (fence !== null) { if (/^```/.test(l)) { html.push("<pre>" + esc(fence.join("\n")) + "</pre>"); fence = null; } else fence.push(l); continue; }
      if (/^```/.test(l)) { flushPara(); flushList(); fence = []; continue; }
      var h = /^(#{1,3})\s+(.*)$/.exec(l);
      if (h) { flushPara(); flushList(); html.push("<h3>" + inline(h[2]) + "</h3>"); continue; }
      var ul = /^\s*[-*]\s+(.*)$/.exec(l), ol = /^\s*\d+[.)]\s+(.*)$/.exec(l);
      if (ul || ol) { flushPara(); var tag = ul ? "ul" : "ol"; if (!list || list.tag !== tag) { flushList(); list = { tag: tag, items: [] }; } list.items.push((ul || ol)[1]); continue; }
      if (!l.trim()) { flushPara(); flushList(); continue; }
      flushList(); para.push(l);
    }
    if (fence !== null) html.push("<pre>" + esc(fence.join("\n")) + "</pre>");
    flushPara(); flushList();
    return html.join("");
  }

  function splitContext(text) {
    var i = text.indexOf("\n\nContext data:\n");
    if (i === -1) return { head: text, ctx: "" };
    return { head: text.slice(0, i), ctx: text.slice(i + "\n\nContext data:\n".length) };
  }

  function timeOf(iso) { try { return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; } }

  function renderChat(view) {
    lastChat = view;
    settleQueueFromTranscript(view.chat);
    var html = "";
    view.chat.forEach(function (m) {
      if (m.role === "system") { html += '<div class="msg system">' + esc(m.text) + "</div>"; return; }
      if (m.role === "agent") {
        html += '<div class="msg agent"><div class="meta"><span class="who">Agent</span><span>' + timeOf(m.at) + "</span></div><div class=\"body\">" + markdown(m.text) + "</div></div>";
        return;
      }
      var parts = splitContext(m.text);
      html += '<div class="msg user"><div class="meta"><span class="who">You</span><span>' + timeOf(m.at) + "</span></div>";
      if (m.anchor) html += '<div class="anchor">' + esc(m.anchor.label || "") + " " + esc(m.anchor.selector || "") + (m.anchor.excerpt ? ' <span class="excerpt">· ' + esc(m.anchor.excerpt) + "</span>" : "") + "</div>";
      html += '<div class="body">' + markdown(parts.head) + "</div>";
      if (parts.ctx) html += '<details class="ctx"><summary>Context data</summary><pre>' + esc(parts.ctx) + "</pre></details>";
      html += '<div class="state' + (m.done ? " done" : "") + '">' + (m.done ? "Done" : m.delivered_seq ? "Delivered to the agent" : "Waiting for the agent to poll") + "</div></div>";
    });
    var lastAgentAt = 0;
    view.chat.forEach(function (m) { if (m.role === "agent") lastAgentAt = Math.max(lastAgentAt, Date.parse(m.at) || 0); });
    var working = sentAt && lastAgentAt < sentAt && !ended && view.status !== "ended";
    if (working) html += '<div class="working"><span class="dot"></span>Working…</div>';
    chatLog.innerHTML = html || '<div class="msg system">Answer questions in the artifact, click an element to annotate it, or write a message, then send.</div>';
    $("panelScroll").scrollTop = $("panelScroll").scrollHeight;

    var listening = Boolean(view.listener);
    presence.hidden = listening || ended;
    agentPill.className = "agent-pill " + (listening ? "on" : "off");
    agentState.textContent = listening ? "listening" : "not listening";
    if (view.status === "ended" && !ended) setEnded(view.ended_by);
  }

  function renderQueue() {
    try { sessionStorage.setItem(storageKey, JSON.stringify(queue)); } catch (e) { /* ignore */ }
    if (!queue.length) { queuedLog.innerHTML = ""; summary.textContent = ""; postToFrame({ type: "lavish:queuedAnchors", selectors: [] }); return; }
    var html = '<div class="queued-title">Queued · ' + queue.length + "</div>";
    queue.forEach(function (q, i) {
      var head = splitContext(q.prompt).head;
      html += '<div class="qitem" title="' + esc(head) + '">' + (q.tag ? '<span class="qtag">' + esc(q.tag) + "</span>" : "") + '<span class="qtext">' + esc(q.text || head) + '</span><button class="qremove" data-i="' + i + '" type="button" aria-label="Remove">×</button></div>';
    });
    queuedLog.innerHTML = html;
    summary.textContent = queue.length + " queued";
    postToFrame({ type: "lavish:queuedAnchors", selectors: queue.map(function (q) { return q.selector; }).filter(Boolean) });
  }
  queuedLog.addEventListener("click", function (ev) {
    var b = ev.target.closest(".qremove");
    if (!b) return;
    queue.splice(Number(b.getAttribute("data-i")), 1);
    renderQueue();
  });

  // The chrome mints each queued prompt's settlement id; the sandboxed iframe is
  // untrusted and never supplies one. A queued note leaves the queue only when
  // the transcript acknowledges that id (upstream invariant), so a lost send
  // response cannot drop or duplicate a note.
  function mintPromptId() {
    var bytes = new Uint8Array(12);
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(bytes) : bytes.forEach(function (_, i) { bytes[i] = Math.floor(Math.random() * 256); });
    return "p" + Array.prototype.map.call(bytes, function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  function enqueue(raw) {
    if (!raw || typeof raw !== "object" || !raw.prompt) return;
    var item = { uid: String(raw.uid || ""), prompt: String(raw.prompt), prompt_id: mintPromptId() };
    ["selector", "tag", "text", "queueKey"].forEach(function (k) { if (raw[k]) item[k] = String(raw[k]); });
    if (raw.target && typeof raw.target === "object") item.target = raw.target;
    if (item.queueKey) queue = queue.filter(function (q) { return q.queueKey !== item.queueKey; });
    queue.push(item);
    renderQueue();
    summary.textContent = queue.length + " queued";
  }
  function settleQueueFromTranscript(chat) {
    var acked = {};
    (chat || []).forEach(function (m) { if (m && m.prompt_id) acked[m.prompt_id] = true; });
    var before = queue.length;
    queue = queue.filter(function (q) { return !acked[q.prompt_id]; });
    if (queue.length !== before) renderQueue();
  }

  function setEnded(by) {
    ended = true;
    endedBanner.hidden = false;
    endedBanner.textContent = by === "agent" ? "The agent ended this session." : "This session has ended.";
    presence.hidden = true;
    chatInput.disabled = true;
    sendBtn.disabled = true;
    sendEndBtn.disabled = true;
    postToFrame({ type: "lavish:setAnnotationMode", enabled: false });
  }

  function showHint(text) { var h = $("sendHint"); h.textContent = text; h.hidden = false; setTimeout(function () { h.hidden = true; }, 2500); }

  function send(endSession) {
    if (ended) return;
    var text = chatInput.value.trim();
    if (text) enqueue({ uid: "m" + Date.now().toString(36), prompt: text, tag: "message" });
    var prompts = queue.map(function (q) { var c = {}; for (var k in q) if (k !== "queueKey") c[k] = q[k]; return c; });
    if (!prompts.length && !endSession) { showHint("Write a message or annotate an element first."); return; }
    sendBtn.disabled = true; sendEndBtn.disabled = true;
    fetch("/api/" + key + "/prompts", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ prompts: prompts, endSession: Boolean(endSession) }) })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (res) {
        if (!res.ok) { showHint(res.d.error || "Could not send"); if (res.d && res.d.ended) setEnded(res.d.ended_by); return; }
        chatInput.value = "";
        // Settle only what the transcript acknowledges; anything else stays queued.
        settleQueueFromTranscript(res.d.chat);
        if (prompts.length) sentAt = Date.now();
        if (endSession) setEnded("user");
      })
      .catch(function () { showHint("The local Lavish server did not answer."); })
      .then(function () { if (!ended) { sendBtn.disabled = false; sendEndBtn.disabled = false; } });
  }
  sendBtn.addEventListener("click", function () { send(false); });
  sendEndBtn.addEventListener("click", function () { if (confirm("Send what is queued and end this review session?")) send(true); });
  chatInput.addEventListener("keydown", function (ev) { if ((ev.metaKey || ev.ctrlKey) && ev.key === "Enter") send(false); });

  /* annotation card */
  var annotTarget = null;
  function openAnnot(sel) {
    annotTarget = sel;
    $("annotTarget").textContent = "<" + sel.tag + "> " + sel.selector;
    $("annotExcerpt").textContent = sel.text || "";
    $("annotInput").value = "";
    annotCard.hidden = false;
    $("annotInput").focus();
  }
  $("annotClose").addEventListener("click", function () { annotCard.hidden = true; annotTarget = null; });
  $("annotQueue").addEventListener("click", function () {
    var note = $("annotInput").value.trim();
    if (!annotTarget || !note) return;
    enqueue({ uid: annotTarget.uid, prompt: note, selector: annotTarget.selector, tag: annotTarget.tag, text: annotTarget.text });
    annotCard.hidden = true; annotTarget = null;
  });

  /* review state inside data-lavish-question scopes survives reloads of the
     artifact and of this page; it is replayed without synthetic events */
  var reviewStateKey = "lavish-local:review-state:" + key;
  var reviewState = null;
  try { reviewState = JSON.parse(sessionStorage.getItem(reviewStateKey) || "null"); } catch (e) { reviewState = null; }

  /* messages from the artifact */
  window.addEventListener("message", function (ev) {
    if (ev.source !== frame.contentWindow) return;
    var msg = ev.data || {};
    if (msg.type === "lavish:queuePrompt") enqueue(msg.prompt);
    else if (msg.type === "lavish:sendQueuedPrompts") send(false);
    else if (msg.type === "lavish:endSession") { if (confirm("End this review session?")) send(true); }
    else if (msg.type === "lavish:select") openAnnot(msg);
    else if (msg.type === "lavish:scroll") lastScroll = { x: msg.x, y: msg.y };
    else if (msg.type === "lavish:status") { var n = $("frameNote"); n.textContent = msg.message || ""; n.hidden = !msg.message; }
    else if (msg.type === "lavish:toggleAnnotationMode") setAnnotate(!annotate);
    else if (msg.type === "lavish:annotationMode") { if (!ended) annotate = Boolean(msg.enabled); annotation.setAttribute("aria-pressed", String(Boolean(msg.enabled))); }
    else if (msg.type === "lavish:reviewState") {
      reviewState = msg.state || null;
      try { sessionStorage.setItem(reviewStateKey, JSON.stringify(reviewState)); } catch (e) { /* ignore */ }
    }
    else if (msg.type === "lavish:ready") {
      postToFrame({ type: "lavish:setAnnotationMode", enabled: annotate && !ended });
      if (lastScroll) postToFrame({ type: "lavish:restoreScroll", x: lastScroll.x, y: lastScroll.y });
      if (reviewState) postToFrame({ type: "lavish:restoreReviewState", state: reviewState });
      renderQueue();
    }
  });

  /* top bar */
  function setAnnotate(on) {
    annotate = Boolean(on);
    annotation.setAttribute("aria-pressed", String(annotate));
    postToFrame({ type: "lavish:setAnnotationMode", enabled: annotate && !ended });
  }
  annotation.addEventListener("click", function () { setAnnotate(!annotate); });
  document.addEventListener("keydown", function (ev) {
    var isMac = /Mac|iPhone|iPad/.test(navigator.platform || "");
    if ((isMac ? ev.metaKey : ev.ctrlKey) && !ev.altKey && !ev.shiftKey && String(ev.key).toLowerCase() === "i") { ev.preventDefault(); setAnnotate(!annotate); }
  }, true);
  var moreBtn = $("moreButton"), moreMenu = $("moreMenu");
  moreBtn.addEventListener("click", function () { moreMenu.hidden = !moreMenu.hidden; moreBtn.setAttribute("aria-expanded", String(!moreMenu.hidden)); });
  document.addEventListener("click", function (ev) { if (!ev.target.closest(".more-wrap")) moreMenu.hidden = true; });
  $("copyPath").addEventListener("click", function () {
    var done = function () { $("copyHint").textContent = "Copied"; setTimeout(function () { $("copyHint").textContent = "Copy"; }, 1500); };
    if (navigator.clipboard) navigator.clipboard.writeText(cfg.file).then(done, done); else done();
  });
  $("reloadArtifact").addEventListener("click", function () { artifactRevision++; loadArtifact(); moreMenu.hidden = true; });
  $("openDirect").addEventListener("click", function () { window.open("/artifact/" + key + "/index.html", "_blank", "noopener"); moreMenu.hidden = true; });
  $("end").addEventListener("click", function () {
    moreMenu.hidden = true;
    if (!confirm("End this review session? Anything queued but not sent is discarded.")) return;
    fetch("/api/" + key + "/end", { method: "POST" }).then(function () { setEnded("user"); });
  });

  /* live updates */
  function connect() {
    var es = new EventSource("/api/" + key + "/events");
    es.addEventListener("chat", function (e) { try { renderChat(JSON.parse(e.data)); } catch (err) { /* ignore */ } });
    es.addEventListener("artifact", function (e) {
      try { artifactRevision = JSON.parse(e.data).artifact_revision || artifactRevision + 1; } catch (err) { artifactRevision++; }
      loadArtifact();
    });
    es.addEventListener("ended", function (e) { try { setEnded(JSON.parse(e.data).ended_by); } catch (err) { setEnded("user"); } });
    es.onerror = function () { es.close(); setTimeout(connect, 2000); };
  }
  fetch("/api/" + key + "/chat").then(function (r) { return r.json(); }).then(renderChat).catch(function () {});
  connect();
  renderQueue();
})();
