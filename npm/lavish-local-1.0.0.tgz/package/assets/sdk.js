/* lavish-local artifact SDK. Injected into the artifact served inside the
 * sandboxed review iframe. Provides window.lavish (queuePrompt,
 * sendQueuedPrompts, endSession, setStatus, snapshot), annotate mode (click an
 * element to comment on it), review-state reporting so answers inside
 * data-lavish-question scopes survive a live reload, and scroll restore.
 * The artifact runs in an opaque origin, so the only channel to the review
 * page is postMessage. Nothing here talks to the network.
 *
 * Contract mirrored from upstream lavish-axi src/artifact-sdk.js:
 *  - queuePrompt(prompt, {uid, selector, tag, text, target, data, queueKey, element})
 *    appends `data` as "\n\nContext data:\n<pretty JSON>" to the prompt.
 *  - queue keys: an explicit queueKey wins; an element inside
 *    [data-lavish-question] gets "question:<key>"; radios "radio:<scope>:<name>";
 *    checkboxes "checkbox:<scope>:<identity>:<option>"; other fields
 *    "field:<scope>:<identity>". A later prompt with the same key replaces the
 *    earlier UNSENT one in the review page's queue.
 *  - annotate mode ignores native controls, editable regions,
 *    [data-lavish-action] elements and the artifact's own opt-out
 *    (<html data-lavish-annotate="off">). Ctrl/Cmd+I toggles it.
 *  - review state (controls inside data-lavish-question scopes, open note draft)
 *    is reported to the review page and replayed after a reload without
 *    synthetic events, so an already-sent answer is never re-queued. */
(function () {
  "use strict";
  if (window.lavish && window.lavish.__local) return;
  var parentWin = window.parent;
  if (!parentWin || parentWin === window) {
    window.lavish = {
      __local: true,
      queuePrompt: function () {},
      sendQueuedPrompts: function () {},
      endSession: function () {},
      getQueuedPrompts: function () { return []; },
      setStatus: function () {},
      snapshot: function () { return ""; }
    };
    return;
  }

  var counter = 0;
  var ids = new WeakMap();
  var annotationMode = document.documentElement.getAttribute("data-lavish-annotate") !== "off";
  var hovered = null;
  var queuedSelectors = [];
  var isMac = /Mac|iPhone|iPad/.test(navigator.platform || "");

  function post(type, payload) {
    var msg = { type: type };
    if (payload) for (var k in payload) if (Object.prototype.hasOwnProperty.call(payload, k)) msg[k] = payload[k];
    parentWin.postMessage(msg, "*");
  }
  function str(v) { return v === undefined || v === null ? "" : String(v); }
  function attr(el, name) { return el && el.getAttribute ? el.getAttribute(name) : null; }
  function closest(el, sel) { try { return el && el.closest ? el.closest(sel) : null; } catch (e) { return null; } }
  function tagName(el) { return el && el.tagName ? el.tagName.toLowerCase() : ""; }

  function uidFor(el) {
    if (!el) return String(++counter);
    var u = ids.get(el);
    if (!u) { u = String(++counter); ids.set(el, u); }
    return u;
  }

  function cssEscape(s) {
    return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function elementPath(el) {
    var parts = [];
    var node = el;
    var depth = 0;
    while (node && node.nodeType === 1 && node !== document.body && depth < 6) {
      var part = tagName(node);
      if (node.id) { parts.unshift("#" + cssEscape(node.id)); break; }
      var parent = node.parentElement;
      if (parent) {
        var same = Array.prototype.filter.call(parent.children, function (c) { return c.tagName === node.tagName; });
        if (same.length > 1) part += ":nth-of-type(" + (same.indexOf(node) + 1) + ")";
      }
      parts.unshift(part);
      node = parent;
      depth++;
    }
    return parts.join(" > ");
  }

  function selectorFor(el) {
    if (!(el instanceof Element)) return "";
    if (el.id && document.querySelectorAll("#" + cssEscape(el.id)).length === 1) return "#" + el.id;
    var tag = tagName(el);
    if (document.getElementsByTagName(tag).length === 1) return tag;
    var cls = Array.prototype.slice.call(el.classList).slice(0, 2).map(function (c) { return "." + cssEscape(c); }).join("");
    if (cls) {
      try { if (document.querySelectorAll(tag + cls).length === 1) return tag + cls; } catch (e) { /* ignore */ }
    }
    return elementPath(el);
  }

  function textOf(el, max) {
    var t = (el && (el.innerText || el.textContent) || "").replace(/\s+/g, " ").trim();
    return t.length > max ? t.slice(0, max - 1) + "…" : t;
  }

  /* ---- queue keys (upstream rules) ---- */
  function scopeKey(el) {
    var scope = closest(el, "form,fieldset") || (el && el.parentElement) || el;
    var tag = tagName(scope) || "scope";
    var explicit = str(attr(scope, "data-lavish-question") || attr(scope, "id") || attr(scope, "name")).trim();
    if (explicit) return tag + ":" + explicit;
    return elementPath(scope) || tag;
  }
  function controlIdentity(el) {
    var identity = str(attr(el, "name") || attr(el, "id") || (el && el.name)).trim();
    return identity || elementPath(el);
  }
  function deriveQueueKey(element, options) {
    if (options && Object.prototype.hasOwnProperty.call(options, "queueKey")) return str(options.queueKey).trim();
    var question = closest(element, "[data-lavish-question]");
    var questionKey = str(attr(question, "data-lavish-question")).trim();
    if (questionKey) return "question:" + questionKey;
    if (!(element instanceof Element)) return "";
    var tag = tagName(element);
    var type = str(attr(element, "type") || element.type).toLowerCase();
    var scope = scopeKey(element);
    if (tag === "input" && type === "radio") {
      var name = str(attr(element, "name") || element.name).trim();
      return name ? "radio:" + scope + ":" + name : "";
    }
    if (tag === "input" && type === "checkbox") {
      var identity = controlIdentity(element);
      var option = str(attr(element, "value")).trim() || str(attr(element, "id") || elementPath(element)).trim();
      return identity ? "checkbox:" + scope + ":" + identity + ":" + option : "";
    }
    if (tag === "select" || tag === "textarea" || (tag === "input" && ["button", "submit", "reset", "file", "image", "hidden", "radio", "checkbox"].indexOf(type) === -1)) {
      var id2 = controlIdentity(element);
      if (id2) return "field:" + scope + ":" + id2;
    }
    return "";
  }

  function queuePrompt(prompt, options) {
    options = options || {};
    var el = options.element instanceof Element ? options.element : null;
    var item = { uid: options.uid ? String(options.uid) : uidFor(el), prompt: str(prompt) };
    var selector = options.selector ? String(options.selector) : (el ? selectorFor(el) : "");
    if (selector) item.selector = selector;
    if (options.tag) item.tag = String(options.tag);
    if (options.text) item.text = String(options.text);
    if (options.target && typeof options.target === "object") item.target = options.target;
    if (options.data !== undefined) item.prompt += "\n\nContext data:\n" + JSON.stringify(options.data, null, 2);
    var queueKey = deriveQueueKey(el, options);
    if (queueKey) item.queueKey = queueKey;
    post("lavish:queuePrompt", { prompt: item });
  }

  function snapshot() {
    var lines = [];
    (function walk(el, depth) {
      if (!(el instanceof Element) || depth > 6 || lines.length > 400) return;
      var t = textOf(el, 80);
      var name = tagName(el) + (el.id ? "#" + el.id : "") + (typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/).slice(0, 2).join(".") : "");
      lines.push(new Array(depth + 1).join("  ") + name + (t ? ' "' + t + '"' : ""));
      Array.prototype.forEach.call(el.children, function (c) { walk(c, depth + 1); });
    })(document.body, 0);
    return lines.join("\n");
  }

  window.lavish = {
    __local: true,
    queuePrompt: queuePrompt,
    sendQueuedPrompts: function () { post("lavish:sendQueuedPrompts"); },
    endSession: function () { post("lavish:endSession"); },
    getQueuedPrompts: function () { return []; },
    setStatus: function (message) { post("lavish:status", { message: String(message) }); },
    snapshot: snapshot
  };

  /* ---- annotate mode ---- */
  var style = document.createElement("style");
  style.setAttribute("data-lavish-sdk", "");
  style.textContent =
    "[data-lavish-hover]{outline:2px solid #f4c95d!important;outline-offset:2px}" +
    "[data-lavish-queued]{outline:2px dashed #3c7ea6!important;outline-offset:2px}" +
    "html[data-lavish-mode=annotate] body{cursor:crosshair}" +
    "html[data-lavish-mode=annotate] :is(button,select,label,summary,a[href],[data-lavish-action],[role=button],[role=link],[role=tab],[role=checkbox],[role=radio],[role=switch],input[type=checkbox],input[type=radio],input[type=submit],input[type=button]){cursor:pointer}" +
    "html[data-lavish-mode=annotate] :is(input,textarea,[contenteditable]:not([contenteditable=false])){cursor:text}";
  (document.head || document.documentElement).appendChild(style);

  var NATIVE = "button,input,select,textarea,option,optgroup,label,summary,[contenteditable]:not([contenteditable='false'])";
  var ARIA = "[role='button'],[role='checkbox'],[role='combobox'],[role='menuitem'],[role='menuitemcheckbox'],[role='menuitemradio'],[role='option'],[role='radio'],[role='switch'],[role='tab'],[role='treeitem'],[role='slider'],[role='textbox'],[role='link']";

  function annotatable(el) {
    if (!(el instanceof Element)) return false;
    if (el === document.body || el === document.documentElement) return false;
    if (closest(el, "[data-lavish-sdk],[data-lavish-ui]")) return false;
    if (closest(el, NATIVE) || closest(el, ARIA) || closest(el, "[data-lavish-action]")) return false;
    return true;
  }

  function setMode(enabled) {
    annotationMode = Boolean(enabled);
    document.documentElement.setAttribute("data-lavish-mode", annotationMode ? "annotate" : "explore");
    if (!annotationMode && hovered) { hovered.removeAttribute("data-lavish-hover"); hovered = null; }
    post("lavish:annotationMode", { enabled: annotationMode });
  }
  setMode(annotationMode);

  document.addEventListener("mouseover", function (ev) {
    if (!annotationMode) return;
    var el = ev.target;
    if (!annotatable(el)) { if (hovered) { hovered.removeAttribute("data-lavish-hover"); hovered = null; } return; }
    if (hovered && hovered !== el) hovered.removeAttribute("data-lavish-hover");
    hovered = el;
    el.setAttribute("data-lavish-hover", "");
  }, true);
  document.addEventListener("mouseout", function (ev) {
    if (hovered && ev.target === hovered) { hovered.removeAttribute("data-lavish-hover"); hovered = null; }
  }, true);
  document.addEventListener("click", function (ev) {
    if (!annotationMode) return;
    var el = ev.target;
    if (!annotatable(el)) return;
    // Modifier-click follows links even in annotate mode (Cmd on macOS, Ctrl elsewhere).
    if (closest(el, "a[href]") && (isMac ? ev.metaKey : ev.ctrlKey)) return;
    ev.preventDefault();
    ev.stopPropagation();
    var sel = window.getSelection && window.getSelection();
    var selected = sel && String(sel).trim();
    var anchorEl = closest(el, "a[href]") || el;
    post("lavish:select", {
      uid: uidFor(anchorEl),
      selector: selectorFor(anchorEl),
      tag: tagName(anchorEl),
      text: selected && selected.length < 2000 ? selected : textOf(anchorEl, 300)
    });
  }, true);

  // Ctrl/Cmd+I toggles annotate/explore from inside the artifact too.
  document.addEventListener("keydown", function (ev) {
    if ((isMac ? ev.metaKey : ev.ctrlKey) && !ev.altKey && !ev.shiftKey && String(ev.key).toLowerCase() === "i") {
      ev.preventDefault();
      post("lavish:toggleAnnotationMode");
    }
  }, true);

  function markQueued(selectors) {
    queuedSelectors.forEach(function (s) {
      try { Array.prototype.forEach.call(document.querySelectorAll(s), function (n) { n.removeAttribute("data-lavish-queued"); }); } catch (e) { /* ignore */ }
    });
    queuedSelectors = selectors || [];
    queuedSelectors.forEach(function (s) {
      try { Array.prototype.forEach.call(document.querySelectorAll(s), function (n) { n.setAttribute("data-lavish-queued", ""); }); } catch (e) { /* ignore */ }
    });
  }

  /* ---- review state: controls inside data-lavish-question scopes ---- */
  function questionControls() {
    var entries = [];
    var scopes = document.querySelectorAll("[data-lavish-question]");
    for (var s = 0; s < scopes.length; s++) {
      var question = str(scopes[s].getAttribute("data-lavish-question"));
      var controls = scopes[s].querySelectorAll("input,select,textarea");
      for (var i = 0; i < controls.length && entries.length < 200; i++) {
        var c = controls[i];
        var type = str(c.getAttribute("type") || c.type || "text").toLowerCase();
        if (["button", "submit", "reset", "file", "image", "password"].indexOf(type) !== -1) continue;
        entries.push({
          el: c,
          key: [question, str(c.getAttribute("name") || c.id), type, str(c.getAttribute("value"))].join("|").slice(0, 300),
          index: i, question: question, type: type
        });
      }
    }
    return entries;
  }
  function collectReviewState() {
    return {
      fields: questionControls().map(function (e) {
        return {
          key: e.key, index: e.index, question: e.question, type: e.type,
          value: str(e.el.value).slice(0, 2000),
          checked: (e.type === "checkbox" || e.type === "radio") ? Boolean(e.el.checked) : null
        };
      })
    };
  }
  var reviewTimer = 0;
  function scheduleReviewStateReport() {
    if (reviewTimer) clearTimeout(reviewTimer);
    reviewTimer = setTimeout(function () { reviewTimer = 0; post("lavish:reviewState", { state: collectReviewState() }); }, 120);
  }
  function restoreReviewState(state) {
    if (!state || !Array.isArray(state.fields) || !state.fields.length) return;
    var entries = questionControls();
    state.fields.forEach(function (field) {
      var match = null;
      for (var i = 0; i < entries.length; i++) if (entries[i].key === field.key) { match = entries[i]; break; }
      if (!match) for (var j = 0; j < entries.length; j++) if (entries[j].question === field.question && entries[j].index === field.index) { match = entries[j]; break; }
      if (!match) return;
      // No synthetic change/input events: the artifact's handlers queue prompts,
      // and replaying them would re-queue answers the user already sent.
      if (field.checked === null || field.checked === undefined) match.el.value = str(field.value);
      else match.el.checked = Boolean(field.checked);
    });
  }
  document.addEventListener("input", function (ev) { if (closest(ev.target, "[data-lavish-question]")) scheduleReviewStateReport(); }, true);
  document.addEventListener("change", function (ev) { if (closest(ev.target, "[data-lavish-question]")) scheduleReviewStateReport(); }, true);

  var scrollTimer = null;
  window.addEventListener("scroll", function () {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function () { post("lavish:scroll", { x: window.scrollX, y: window.scrollY }); }, 150);
  }, { passive: true });

  window.addEventListener("message", function (event) {
    if (event.source !== parentWin) return;
    var msg = event.data || {};
    if (msg.type === "lavish:setAnnotationMode") setMode(msg.enabled);
    if (msg.type === "lavish:queuedAnchors") markQueued(Array.isArray(msg.selectors) ? msg.selectors : []);
    if (msg.type === "lavish:restoreScroll") window.scrollTo(Number(msg.x) || 0, Number(msg.y) || 0);
    if (msg.type === "lavish:restoreReviewState") restoreReviewState(msg.state);
    if (msg.type === "lavish:requestSnapshot") post("lavish:snapshot", { snapshot_request_id: msg.snapshot_request_id, snapshot: snapshot() });
    if (msg.type === "lavish:revealElement") {
      try { var t = document.querySelector(String(msg.selector || "")); if (t) { t.scrollIntoView({ block: "center" }); t.setAttribute("data-lavish-hover", ""); setTimeout(function () { t.removeAttribute("data-lavish-hover"); }, 1200); } } catch (e) { /* ignore */ }
    }
  });

  post("lavish:ready", { title: document.title || "", annotate: annotationMode });
})();
