#!/usr/bin/env bash
# Behaviours ported from upstream lavish-axi: security headers, prompt_id
# dedupe, browser-disconnect grace, last-session self-shutdown with restart
# from persisted state, and LISTENER_ACTIVE/takeover.
set -u
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(cd "$HERE/.." && pwd)
export PATH="$ROOT/bin:$PATH"
export LAVISH_AXI_PORT=${LAVISH_AXI_PORT:-4396} LAVISH_AXI_NO_OPEN=1 LAVISH_AXI_NO_TAILSCALE=1 LAVISH_AXI_DISCONNECT_GRACE_MS=2000
LAB=$(mktemp -d "${TMPDIR:-/tmp}/lavish-local-life.XXXXXX")
export LAVISH_AXI_STATE_DIR="$LAB/state"
BASE="http://127.0.0.1:$LAVISH_AXI_PORT"
pass() { printf 'ok - %s\n' "$1"; }
fail() { printf 'not ok - %s\n' "$1" >&2; lavish-axi stop >/dev/null 2>&1; rm -rf "$LAB"; exit 1; }
trap 'lavish-axi stop >/dev/null 2>&1; rm -rf "$LAB"' EXIT
mkdir -p "$LAB/.lavish"
printf '<!doctype html><html><head><meta charset="utf-8"><title>life</title><style>body{background:#fff}</style></head><body><p id="p">hello</p></body></html>' > "$LAB/.lavish/a.html"
A="$LAB/.lavish/a.html"

url=$(lavish-axi "$A" | sed -n 's/^[[:space:]]*url:[[:space:]]*//p' | head -1 | tr -d '"'); key=${url##*/}

h=$(curl -s -D - -o /dev/null "$url"); printf '%s' "$h" | grep -qi '^x-frame-options: DENY' || fail "session page lacks X-Frame-Options: $h"
printf '%s' "$h" | grep -qi "frame-ancestors 'none'" || fail "session page lacks frame-ancestors"
h=$(curl -s -D - -o /dev/null "$BASE/artifact/$key/index.html"); printf '%s' "$h" | grep -qi '^content-security-policy: sandbox allow-scripts' || fail "artifact lacks sandbox CSP: $h"
pass "security headers: review page not framable, artifact carries the sandbox CSP"

body='{"prompts":[{"uid":"1","prompt":"note","tag":"message","prompt_id":"pabc123"}]}'
curl -fsS -X POST -H "Origin: $BASE" -H 'content-type: application/json' "$BASE/api/$key/prompts" -d "$body" >/dev/null || fail "first post"
r=$(curl -fsS -X POST -H "Origin: $BASE" -H 'content-type: application/json' "$BASE/api/$key/prompts" -d "$body") || fail "second post"
printf '%s' "$r" | grep -q '"pending_prompts":1' || fail "duplicate prompt_id was queued twice: $r"
out=$(lavish-axi poll "$A" --timeout-ms 1000); printf '%s\n' "$out" | grep -q '^prompts\[1\]' || fail "expected one prompt: $out"
printf '%s\n' "$out" | grep -q 'prompt_id' && fail "prompt_id leaked to the agent"
pass "prompt_id: a resend is ignored and the id never reaches the agent"

( lavish-axi poll "$A" --timeout-ms 5000 > "$LAB/p1.out" 2>&1 ) &
sleep 0.4
out=$(lavish-axi poll "$A" --timeout-ms 500); printf '%s\n' "$out" | grep -q 'code: LISTENER_ACTIVE' || fail "second poll should be refused: $out"
out=$(lavish-axi poll "$A" --timeout-ms 500 --takeover); printf '%s\n' "$out" | grep -q 'status: waiting' || fail "takeover poll: $out"
wait; grep -q 'LISTENER_REPLACED' "$LAB/p1.out" || fail "displaced poll did not learn LISTENER_REPLACED: $(cat "$LAB/p1.out")"
pass "exclusive poll ownership: LISTENER_ACTIVE and --takeover -> LISTENER_REPLACED"

curl -sN "$BASE/api/$key/events" > /dev/null 2>&1 &
sse=$!
sleep 0.5
( lavish-axi poll "$A" --timeout-ms 15000 > "$LAB/p2.out" 2>&1 ) &
sleep 0.5
kill $sse 2>/dev/null; wait $sse 2>/dev/null
start=$(date +%s); wait %2 2>/dev/null; wait; elapsed=$(( $(date +%s) - start ))
grep -q 'status: browser_disconnected' "$LAB/p2.out" || fail "expected browser_disconnected after the grace: $(cat "$LAB/p2.out")"
[ "$elapsed" -le 6 ] || fail "grace took too long: ${elapsed}s"
pass "browser_disconnected after the configured grace (${elapsed}s) once every review page is gone"

curl -fsS -X POST -H "Origin: $BASE" "$BASE/api/$key/end" >/dev/null || fail "end"
for _ in $(seq 1 30); do curl -fsS -m 1 "$BASE/health" >/dev/null 2>&1 || break; sleep 0.2; done
curl -fsS -m 1 "$BASE/health" >/dev/null 2>&1 && fail "server stayed up after the last session ended with nothing connected"
out=$(lavish-axi "$A"); printf '%s\n' "$out" | grep -q 'status: user-ended' || fail "restart from persisted state: $out"
out=$(lavish-axi "$A" --reopen); printf '%s\n' "$out" | grep -q 'status: opened' || fail "reopen after restart: $out"
pass "last session ended -> server stops; the next command restarts it from state.json"

lavish-axi stop >/dev/null
echo "all ok"
