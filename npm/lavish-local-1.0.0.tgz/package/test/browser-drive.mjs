// Drive a headless Chromium through the Chrome DevTools Protocol with nothing
// but node: built-ins (Node 22 ships a WebSocket client). Used by the e2e test
// to prove the review page works end to end: the artifact renders in the
// sandboxed iframe, an answer queued from inside the artifact reaches the
// Conversation panel, Send to Agent posts it, and a screenshot is taken.
//
// usage: node browser-drive.mjs <session-url> <screenshot.png> [answer-value]
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const [, , url, shot, answer = "yes"] = process.argv;
if (!url || !shot) {
  console.error("usage: browser-drive.mjs <session-url> <screenshot.png> [answer-value]");
  process.exit(2);
}
const chromium = process.env.CHROMIUM || "/usr/bin/chromium";
const profile = fs.mkdtempSync(path.join(os.tmpdir(), "ll-chrome-"));
const proc = spawn(chromium, [
  "--headless=new", "--no-sandbox", "--disable-gpu", "--no-first-run", "--disable-extensions",
  // keep the sandboxed artifact iframe in-process so its execution context is
  // visible from the page session (otherwise it becomes a separate OOPIF target)
  "--disable-site-isolation-trials", "--disable-features=IsolateOrigins,site-per-process,IsolateSandboxedIframes",
  "--disable-background-networking", "--disable-component-update", "--disable-sync", "--disable-default-apps",
  "--remote-debugging-port=0", `--user-data-dir=${profile}`, "--window-size=1500,1000", "about:blank"
], { stdio: ["ignore", "ignore", "pipe"] });

const wsUrl = await new Promise((resolve, reject) => {
  let buf = "";
  const t = setTimeout(() => reject(new Error("chromium did not announce DevTools: " + buf.slice(-500))), 20000);
  proc.stderr.on("data", (d) => {
    buf += d.toString();
    const m = /DevTools listening on (ws:\/\/\S+)/.exec(buf);
    if (m) { clearTimeout(t); resolve(m[1]); }
  });
  proc.on("exit", (c) => reject(new Error("chromium exited " + c + ": " + buf.slice(-500))));
});

const browserWs = new WebSocket(wsUrl);
let id = 0;
const pending = new Map();
const events = [];
const waiters = [];
browserWs.onmessage = (e) => {
  const msg = JSON.parse(e.data);
  if (msg.id && pending.has(msg.id)) { const { resolve, reject } = pending.get(msg.id); pending.delete(msg.id); msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result); }
  else if (msg.method) { events.push(msg); for (const w of [...waiters]) if (w.test(msg)) { waiters.splice(waiters.indexOf(w), 1); w.resolve(msg); } }
};
await new Promise((r) => (browserWs.onopen = r));
function send(method, params = {}, sessionId) {
  return new Promise((resolve, reject) => { const i = ++id; pending.set(i, { resolve, reject }); browserWs.send(JSON.stringify({ id: i, method, params, ...(sessionId ? { sessionId } : {}) })); });
}
function waitEvent(test, ms = 15000) {
  const hit = events.find(test);
  if (hit) return Promise.resolve(hit);
  return new Promise((resolve, reject) => { const w = { test, resolve }; waiters.push(w); setTimeout(() => reject(new Error("timeout waiting for event")), ms); });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const { targetId } = await send("Target.createTarget", { url: "about:blank" });
const { sessionId } = await send("Target.attachToTarget", { targetId, flatten: true });
await send("Page.enable", {}, sessionId);
await send("Runtime.enable", {}, sessionId);
await send("Page.navigate", { url }, sessionId);
await waitEvent((m) => m.method === "Page.loadEventFired" && m.sessionId === sessionId);

// Find the artifact iframe's LIVE execution context (opaque origin,
// auxData.isDefault). The frame first gets an about:blank context that is
// destroyed when the artifact commits, so only contexts not yet destroyed count.
function liveContexts() {
  const live = new Map();
  for (const m of events) {
    if (m.sessionId !== sessionId) continue;
    if (m.method === "Runtime.executionContextCreated") live.set(m.params.context.id, m.params.context);
    else if (m.method === "Runtime.executionContextDestroyed") live.delete(m.params.executionContextId);
    else if (m.method === "Runtime.executionContextsCleared") live.clear();
  }
  return [...live.values()];
}
async function resolveFrameCtx() {
  for (let i = 0; i < 150; i++) {
    const tree = await send("Page.getFrameTree", {}, sessionId);
    const child = (tree.frameTree.childFrames || []).find((f) => /\/artifact\//.test(f.frame.url));
    if (child) {
      const ctx = liveContexts().find((c) => c.auxData && c.auxData.frameId === child.frame.id && c.auxData.isDefault);
      if (ctx) return ctx;
    }
    await sleep(100);
  }
  const tree = await send("Page.getFrameTree", {}, sessionId);
  throw new Error("artifact iframe context not found\nframes: " + JSON.stringify(tree.frameTree, null, 1).slice(0, 1500));
}
// The stock page reloads the artifact once its layout handshake completes, so
// wait until the frame's context has been stable for a moment before using it.
let frameCtx = await resolveFrameCtx();
for (let stable = 0; stable < 4; ) {
  await sleep(500);
  const now = await resolveFrameCtx();
  if (now.id === frameCtx.id) stable++;
  else { frameCtx = now; stable = 0; }
}

async function evalIn(_ctxId, expression) {
  for (let attempt = 0; attempt < 12; attempt++) {
    try {
      const r = await send("Runtime.evaluate", { expression, contextId: frameCtx.id, returnByValue: true, awaitPromise: true }, sessionId);
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.text + " " + JSON.stringify(r.exceptionDetails.exception || {}));
      return r.result.value;
    } catch (err) {
      if (!/Cannot find context/.test(String(err.message))) throw err;
      await sleep(500);
      frameCtx = await resolveFrameCtx();
    }
  }
  throw new Error("artifact frame context kept disappearing");
}
// Chrome-side probes are best effort so the same driver works against the
// stock Lavish page (different element ids) and the replica.
async function evalMain(expression) {
  const r = await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true }, sessionId);
  if (r.exceptionDetails) return null;
  return r.result.value;
}

const report = {};
report.artifact_title = await evalIn(frameCtx.id, "document.title");
report.sdk_present = await evalIn(frameCtx.id, "typeof window.lavish === 'object' && typeof window.lavish.queuePrompt === 'function'");
report.cards = await evalIn(frameCtx.id, "document.querySelectorAll('form[data-lavish-question]').length");
report.first_question = await evalIn(frameCtx.id, "(document.querySelector('form[data-lavish-question]')||{}).getAttribute ? document.querySelector('form[data-lavish-question]').getAttribute('data-lavish-question') : null");
// Answer the first card from inside the artifact exactly as a human would:
// pick a radio, press Queue answer.
report.clicked = await evalIn(frameCtx.id, `(() => {
  const form = document.querySelector('form[data-lavish-question]');
  if (!form) return 'no-form';
  const radio = form.querySelector('input[type=radio][value=${JSON.stringify(answer)}]') || form.querySelector('input[type=radio]');
  if (!radio) return 'no-radio';
  radio.click();
  const btn = form.querySelector('button[type=submit]');
  btn.click();
  return radio.value;
})()`);
await sleep(500);
report.queued_in_panel = await evalMain("document.getElementById('queuedLog').children.length");
report.panel_summary = await evalMain("document.getElementById('panelSummary').textContent");
report.agent_pill = await evalMain("document.getElementById('agentState').textContent");
await evalMain("document.getElementById('chatInput').value = 'Sent from the headless browser test.'");
await evalMain("document.getElementById('send').click()");
await sleep(1200);
report.queued_after_send = await evalMain("document.getElementById('queuedLog').children.length");
report.chat_user_messages = await evalMain("document.querySelectorAll('#chatLog .msg.user').length");
report.chat_text = await evalMain("document.getElementById('chatLog').innerText.slice(0, 400)");
const { data } = await send("Page.captureScreenshot", { format: "png" }, sessionId);
fs.writeFileSync(shot, Buffer.from(data, "base64"));
report.screenshot = shot;
console.log(JSON.stringify(report, null, 2));
await send("Browser.close").catch(() => {});
await new Promise((resolve) => {
  const t = setTimeout(() => { proc.kill("SIGKILL"); resolve(); }, 3000);
  proc.once("exit", () => { clearTimeout(t); resolve(); });
});
fs.rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
