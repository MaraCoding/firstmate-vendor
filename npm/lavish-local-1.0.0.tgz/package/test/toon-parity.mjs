// Byte-for-byte parity of lib/toon.mjs against output captured from stock
// lavish-axi 0.1.90 (test/fixtures/stock-*.out, captured 2026-10-25).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { encode } from "../lib/toon.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const FIX = path.join(HERE, "fixtures");
const file = "/tmp/claude-1001/-home-molt-admin/25d16e69-e23e-4e4d-b1da-c0ec6c58a18e/scratchpad/lav-observe/.lavish/bearings-board.html";
let failed = 0;
function check(name, want, got) {
  const ok = want === got;
  console.log(`${ok ? "ok" : "not ok"} - ${name}`);
  if (!ok) {
    failed++;
    console.log("--- want\n" + want + "--- got\n" + got);
  }
}

const p1 = "Captain's Call answer - Guard placeholder: yes\n\nContext data:\n{\n  \"schema\": \"fm-bearings-answer.v1\",\n  \"question\": \"sample-call\",\n  \"selection\": \"yes\",\n  \"note\": \"\"\n}";
check(
  "feedback table form",
  fs.readFileSync(path.join(FIX, "stock-poll-feedback.out"), "utf8"),
  encode({ session: { file, status: "feedback" }, prompts: [{ uid: "2", prompt: p1, selector: "form", tag: "choice", text: "Guard placeholder -> yes" }, { uid: "3", prompt: "hello agent", selector: "", tag: "message", text: "" }], dom_snapshot: "" })
);
const p2 = "Captain's Call answer - Guard placeholder: later\n\nContext data:\n{\n  \"schema\": \"fm-bearings-answer.v1\",\n  \"question\": \"sample-call\",\n  \"selection\": \"later\",\n  \"note\": \"\",\n  \"close\": \"release\"\n}";
check(
  "feedback list form with nested target and session_ended",
  fs.readFileSync(path.join(FIX, "stock-poll-end.out"), "utf8"),
  encode({ session: { file, status: "feedback", session_ended: true, ended_by: "user" }, prompts: [{ uid: "4", prompt: p2, selector: "form", tag: "choice", text: "Guard placeholder -> later", target: { type: "element" } }], dom_snapshot: "" })
);
check(
  "open block",
  fs.readFileSync(path.join(FIX, "stock-open.out"), "utf8").split("next_step:")[0],
  encode({ session: { file, url: "http://127.0.0.1:4399/session/e9cccf8bcf07ddd9", status: "opened" } })
);
check(
  "session listing row",
  `sessions[1]{file,status,url,pending_prompts,listener}:\n  ${file},open,"http://127.0.0.1:4399/session/e9cccf8bcf07ddd9",0,none\n`,
  encode({ sessions: [{ file, status: "open", url: "http://127.0.0.1:4399/session/e9cccf8bcf07ddd9", pending_prompts: 0, listener: "none" }] })
);
console.log(encode({ a: "2 items", b: "x: y", c: "-dash", d: "07", e: "1e5", f: "ok, fine", g: "true", h: " pad", i: "a\tb", j: "#hash", k: "[x]", l: 5, m: null, n: [], o: ["x", "y, z"] }));
process.exit(failed ? 1 : 0);
