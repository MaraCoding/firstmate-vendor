#!/usr/bin/env bash
# lavish-local end-to-end: CLI cycle against a sample board, firstmate adapter
# parse of the poll output, and a headless Chromium click-through.
# Env: LAVISH_AXI_PORT (default 4397), FM_ROOT (firstmate checkout for the
# adapter check; skipped when absent), CHROMIUM (default /usr/bin/chromium).
set -u
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(cd "$HERE/.." && pwd)
FM_ROOT=${FM_ROOT:-$HOME/firstmate}
export PATH="$ROOT/bin:$PATH"
export LAVISH_AXI_PORT=${LAVISH_AXI_PORT:-4397} LAVISH_AXI_NO_OPEN=1 LAVISH_AXI_NO_TAILSCALE=1
LAB=$(mktemp -d "${TMPDIR:-/tmp}/lavish-local-e2e.XXXXXX")
export LAVISH_AXI_STATE_DIR="$LAB/state"
pass() { printf 'ok - %s\n' "$1"; }
fail() { printf 'not ok - %s\n' "$1" >&2; lavish-axi stop >/dev/null 2>&1; rm -rf "$LAB"; exit 1; }
trap 'lavish-axi stop >/dev/null 2>&1; rm -rf "$LAB"' EXIT

mkdir -p "$LAB/.lavish"
TEMPLATE="$FM_ROOT/.agents/skills/bearings/assets/board-template.html"
if [ -f "$TEMPLATE" ]; then
  payload='{"schema":"fm-bearings-board.v1","home":"e2e","generated":"2026-01-01T00:00Z","prs_live":false,"captains_call":[{"key":"sample-call","type":"decision","repo":"sample","title":"Guard placeholder","about":"about","decide":"decide","options":[{"value":"yes","label":"Yes"},{"value":"later","label":"Later"}],"recommend_value":"yes","close":"release"}],"underway":[],"landed":[],"charted":[]}'
  BOARD_JSON="$payload" perl -pe 's/^\Q__FM_BEARINGS_BOARD_DATA__\E$/$ENV{BOARD_JSON}/' "$TEMPLATE" > "$LAB/.lavish/board.html"
else
  cat > "$LAB/.lavish/board.html" <<'HTML'
<!doctype html><html><head><meta charset="utf-8"><title>e2e board</title><style>body{background:#fff;font-family:sans-serif}</style></head>
<body><h1>e2e</h1><form data-lavish-question="sample-call"><label><input type="radio" name="answer" value="yes">Yes</label><label><input type="radio" name="answer" value="later">Later</label><button type="submit">Queue answer</button></form>
<script>document.querySelector('form').addEventListener('submit',function(e){e.preventDefault();var v=new FormData(e.target).get('answer');window.lavish.queuePrompt("Answer: "+v,{tag:"choice",text:"Guard placeholder -> "+v,element:e.target,data:{schema:"fm-bearings-answer.v1",question:"sample-call",selection:v,note:""}});});</script></body></html>
HTML
fi
BOARD="$LAB/.lavish/board.html"

v=$(lavish-axi --version) && [ "$v" = "0.1.90-local" ] || fail "--version: $v"
pass "--version is 0.1.90-local"

out=$(lavish-axi "$BOARD") || fail "open failed: $out"
url=$(printf '%s\n' "$out" | sed -n 's/^[[:space:]]*url:[[:space:]]*//p' | head -1 | tr -d '"')
case "$url" in http://127.0.0.1:$LAVISH_AXI_PORT/session/*) ;; *) fail "unexpected url: $url" ;; esac
printf '%s\n' "$out" | grep -q '^  status: opened$' || fail "open status: $out"
pass "open prints the session url and status: opened"

lavish-axi | grep -F "$BOARD," | grep -q ',open,' || fail "listing does not show the session open"
pass "listing shows the session open"

key=${url##*/}
[ "$key" = "$(printf '%s' "$BOARD" | sha256sum | cut -c1-16)" ] || fail "session key is not sha256(realpath)[:16]"
jq -e --arg f "$BOARD" --arg u "$url" '.sessions[] | select(.file == $f and .url == $u)' "$LAB/state/state.json" >/dev/null || fail "state.json lacks the session"
pass "session key and state.json match the lavish-axi contract"

( lavish-axi poll "$BOARD" --timeout-ms 60000 > "$LAB/poll.out" 2>&1 ) &
sleep 0.5
node "$HERE/browser-drive.mjs" "$url" "$LAB/board.png" yes > "$LAB/drive.json" 2>&1 || fail "browser drive failed: $(tail -5 "$LAB/drive.json")"
wait
grep -q '"clicked": "yes"' "$LAB/drive.json" || fail "the answer was not clicked: $(cat "$LAB/drive.json")"
grep -q '"queued_after_send": 0' "$LAB/drive.json" || fail "the queue was not sent: $(cat "$LAB/drive.json")"
pass "headless Chromium answered the card and sent it"

grep -q '^  status: feedback$' "$LAB/poll.out" || fail "poll did not return feedback: $(cat "$LAB/poll.out")"
grep -q '^prompts\[2\]{uid,prompt,selector,tag,text}:$' "$LAB/poll.out" || fail "poll table header: $(cat "$LAB/poll.out")"
pass "poll returned the feedback table"

if [ -x "$FM_ROOT/bin/fm-procevent-lavish.sh" ]; then
  ans=$("$FM_ROOT/bin/fm-procevent-lavish.sh" answers "$LAB/poll.out") || fail "firstmate adapter could not read the answers"
  printf '%s\n' "$ans" | grep -q "^sample-call	yes	" || fail "adapter answers: $ans"
  [ "$("$FM_ROOT/bin/fm-procevent-lavish.sh" classify "$LAB/poll.out")" = feedback ] || fail "adapter classify"
  pass "firstmate's lavish adapter parses the replica's poll output"
fi

out=$(lavish-axi reply "$BOARD" --agent-reply "Done.") && printf '%s\n' "$out" | grep -q 'status: sent' || fail "reply: $out"
pass "reply is accepted"

curl -fsS -X POST -H "Origin: http://127.0.0.1:$LAVISH_AXI_PORT" "http://127.0.0.1:$LAVISH_AXI_PORT/api/$key/end" >/dev/null || fail "browser end route"
out=$(lavish-axi "$BOARD") || fail "open after user end exited nonzero"
printf '%s\n' "$out" | grep -q 'status: user-ended' || fail "open after user end: $out"
lavish-axi | grep -F "$BOARD," | grep -q ',open,' && fail "ended session still listed open"
out=$(lavish-axi "$BOARD" --reopen) && printf '%s\n' "$out" | grep -q 'status: opened' || fail "reopen: $out"
pass "user-ended sessions refuse a plain open and accept --reopen"

out=$(lavish-axi poll "$BOARD" --timeout-ms 800) && printf '%s\n' "$out" | grep -q 'status: waiting' || fail "waiting poll: $out"
out=$(lavish-axi end "$BOARD") && printf '%s\n' "$out" | grep -q 'status: ended' || fail "end: $out"
out=$(lavish-axi poll "$BOARD" --timeout-ms 800) && printf '%s\n' "$out" | grep -q 'ended_by: agent' || fail "poll on agent-ended: $out"
pass "waiting, agent end, and ended poll shapes"

out=$(lavish-axi stop) && printf '%s\n' "$out" | grep -q 'status: stopped' || fail "stop: $out"
pass "stop"
echo "all ok"
