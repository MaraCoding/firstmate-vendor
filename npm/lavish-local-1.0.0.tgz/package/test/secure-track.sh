#!/usr/bin/env bash
# Install the replica for the secure track and prove the /bearings lavish board
# path works through it: bootstrap gate, audited build cycle (0 connects),
# live build, headless click-through, captain hold released by the listener.
set -u
FM_ROOT=${FM_ROOT:-$HOME/firstmate}
PORT=${LAVISH_AXI_PORT:-4388}
OUT=${OUT:-$HOME/lavish-local/test/out-secure}
mkdir -p "$OUT"
cd "$FM_ROOT" || exit 1

echo "=== 1. install: ~/.local/bin/lavish-axi -> replica"
ln -sfn "$HOME/lavish-local/bin/lavish-axi" "$HOME/.local/bin/lavish-axi"
hash -r
echo "which: $(command -v lavish-axi) -> $(readlink -f "$(command -v lavish-axi)")"
echo "version: $(lavish-axi --version)"

echo "=== 2. secure track port: LAVISH_AXI_PORT=$PORT in ~/.local/bin/fm-pi"
if ! grep -q 'LAVISH_AXI_PORT' "$HOME/.local/bin/fm-pi"; then
  sed -i "s|^exec pi|export LAVISH_AXI_PORT=$PORT  # replica port; stock control (fmcontrol) keeps 4387\nexport LAVISH_AXI_NO_OPEN=1\nexec pi|" "$HOME/.local/bin/fm-pi"
fi
cat "$HOME/.local/bin/fm-pi"
export LAVISH_AXI_PORT=$PORT LAVISH_AXI_NO_OPEN=1

echo "=== 3. firstmate's own gates"
bin/fm-bootstrap.sh lavish-compatible; echo "lavish-compatible rc=$?"
bin/fm-bootstrap.sh lavish-reply-compatible; echo "lavish-reply-compatible rc=$? (0 = confirmed reply path)"

echo "=== 4. seed two captain holds in the secure home"
chmod 700 data state 2>/dev/null; mkdir -p data state; chmod 700 data state
bin/fm-tasks-axi.sh add dial-nested-fan "Dial nested fan editor" --kind ship --repo sshhip --queue >/dev/null 2>&1 || true
bin/fm-captain-hold.sh hold dial-nested-fan --reason "Prioritize nested rings now?" >/dev/null 2>&1 || true
bin/fm-tasks-axi.sh add release-notes-2-1 "Approve the 2.1.0 release notes" --kind docs --repo juegos --queue >/dev/null 2>&1 || true
bin/fm-captain-hold.sh hold release-notes-2-1 --reason "Ship the notes as drafted or trim the changelog?" >/dev/null 2>&1 || true
bin/fm-bearings-snapshot.sh --json 2>/dev/null | jq -c '[.decisions_open[].id]'

jq -n --arg home "molt_admin/firstmate (secure)" --arg gen "$(date -u +%Y-%m-%dT%H:%MZ)" '
{ schema: "fm-bearings-board.v1", home: $home, generated: $gen, prs_live: false,
  captains_call: [
    { key: "dial-nested-fan", type: "decision", repo: "sshhip", title: "Dial nested fan editor",
      about: "Post-#435 nested-ring follow-up: fan-drill nested rings like the live dial.", decide: "Prioritize nested rings now?",
      options: [ { value: "prioritize", label: "Prioritize now", hint: "Release and ship" }, { value: "later", label: "Later", hint: "Keep held until you call it" }, { value: "drop", label: "Drop", hint: "Close the follow-up" } ],
      recommend_value: "later", close: "release" },
    { key: "release-notes-2-1", type: "decision", repo: "juegos", title: "Approve the 2.1.0 release notes",
      about: "Draft notes cover Cien Dijeron scoring and the host gate.", decide: "Ship the notes as drafted or trim the changelog?",
      options: [ { value: "ship", label: "Ship as drafted", hint: "Publish with the full changelog" }, { value: "trim", label: "Trim first", hint: "Cut the changelog to user-facing items" } ],
      recommend_value: "ship" } ],
  underway: [], landed: [], charted: [] }' > "$OUT/payload.json"

echo "=== 5. audited build cycle (build, then retire/end/stop so strace can finish)"
cat > "$OUT/audited-cycle.sh" <<EOF
#!/usr/bin/env bash
set -u
cd "$FM_ROOT"
bin/fm-bearings-board.sh build "$OUT/payload.json"
rc=\$?
sleep 2
bin/fm-procevent-lavish.sh retire "\$(bin/fm-bearings-board.sh path)" >/dev/null 2>&1
lavish-axi end "\$(bin/fm-bearings-board.sh path)" >/dev/null 2>&1
lavish-axi stop >/dev/null 2>&1
sleep 1
exit \$rc
EOF
chmod +x "$OUT/audited-cycle.sh"
rm -rf "$OUT/audit"
bin/fm-egress-audit.sh --out "$OUT/audit" -- "$OUT/audited-cycle.sh" > "$OUT/audit.txt" 2>&1
echo "audit rc=$?"
grep -v next_step "$OUT/audit/stdout" | head -12
cat "$OUT/audit/report.txt"

echo "=== 6. live build (unaudited) so the board stays up"
bin/fm-bearings-board.sh build "$OUT/payload.json" 2>&1 | grep -v next_step
echo "build rc=${PIPESTATUS[0]}"
bin/fm-procevent.sh list | head -3
url=$(jq -r '.sessions[] | select(.file | endswith("bearings-board.html")) | .url' "$HOME/.lavish-axi/state.json")
echo "session url: $url"

echo "=== 7. headless click-through (answer: later)"
key=${url##*/}
node "$HOME/lavish-local/test/browser-drive.mjs" "http://127.0.0.1:$PORT/session/$key" "$OUT/secure-board.png" later 2>&1 | tail -16
for _ in $(seq 1 45); do bin/fm-captain-hold.sh open dial-nested-fan >/dev/null 2>&1 || break; sleep 1; done
echo "--- hold still open? (exit 0 = yes)"; bin/fm-captain-hold.sh open dial-nested-fan; echo "rc=$?"
bin/fm-tasks-axi.sh show dial-nested-fan --full 2>&1 | grep -E '^  (state|held|body)' | head -5
bin/fm-procevent.sh list | head -3
echo "=== done; board url for the captain: $url"
